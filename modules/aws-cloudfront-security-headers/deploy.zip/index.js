exports.handler = (event, context, callback) => {
    
    //Get contents of response
    const response = event.Records[0].cf.response;
    const headers = response.headers;


    
    
    headers["content-security-policy"] = [{key: "Content-Security-Policy", value: "default-src 'self' 'unsafe-inline' 'unsafe-eval' https: http: data: wss: blob:"}];
    
    
    
    headers["permissions-policy"] = [{key: "Permissions-Policy", value: "accelerometer=(self), ambient-light-sensor=(self), autoplay=(self), battery=(self), camera=(self), cross-origin-isolated=(self), display-capture=(self), document-domain=(self), encrypted-media=(self), execution-while-not-rendered=(self), execution-while-out-of-viewport=(self), fullscreen=(self), geolocation=(self), gyroscope=(self), magnetometer=(self), microphone=(self), midi=(self), navigation-override=(self), payment=(self), picture-in-picture=(self), publickey-credentials-get=(self), screen-wake-lock=(self), sync-xhr=(self), usb=(self), web-share=(self), xr-spatial-tracking=(self)"}];
    
    
    
    headers["referrer-policy"] = [{key: "Referrer-Policy", value: "same-origin"}];
    
    
    
    headers["server"] = [{key: "Server", value: "CloudFront"}];
    
    
    
    headers["strict-transport-security"] = [{key: "Strict-Transport-Security", value: "max-age=63072000; includeSubdomains; preload"}];
    
    
    
    headers["x-content-type-options"] = [{key: "X-Content-Type-Options", value: "nosniff"}];
    
    
    
    headers["x-frame-options"] = [{key: "X-Frame-Options", value: "SAMEORIGIN"}];
    
    
    
    headers["x-xss-protection"] = [{key: "X-XSS-Protection", value: "1; mode=block"}];
    
    
    //Return modified response
    callback(null, response);
};
