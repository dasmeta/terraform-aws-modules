exports.handler = (event, context, callback) => {
    
    //Get contents of response
    const response = event.Records[0].cf.response;
    const headers = response.headers;


    
    
    headers["content-security-policy"] = [{key: "Content-Security-Policy", value: "default-src 'self' https://*.stripe.com https://*.google.com https://*.googleapis.com https://unpkg.com https://*.segment.com http://*.segment.com https://*.amazonaws.com https://*.intercom.io https://*.intercomcdn.com https://*.gstatic.com http://*.google-analytics.com https://*.google-analytics.com https://*.slack-edge.com https://*.gravatar.com https://*.wp.com https://*.squarespace.com https://*.squarespace-cdn.com https://*.segment.io https://*.ingest.sentry.io https://*.intercomassets.com https://s-install.avcdn.net https://*.pushmetrics.io https://*.analytixlive.com https://dashboard.analytixapps.com http://localhost:3000; script-src 'self' https://*.stripe.com https://*.google.com https://*.googleapis.com https://unpkg.com https://*.segment.com http://*.segment.com https://*.amazonaws.com https://*.intercom.io https://*.intercomcdn.com https://*.gstatic.com http://*.google-analytics.com https://*.google-analytics.com https://*.slack-edge.com https://*.gravatar.com https://*.wp.com https://*.squarespace.com https://*.squarespace-cdn.com https://*.segment.io https://*.ingest.sentry.io https://*.intercomassets.com https://s-install.avcdn.net https://*.pushmetrics.io https://*.analytixlive.com https://dashboard.analytixapps.com http://localhost:3000; connect-src * 'self' https://*.stripe.com https://*.google.com https://*.googleapis.com https://unpkg.com https://*.segment.com http://*.segment.com https://*.amazonaws.com https://*.intercom.io https://*.intercomcdn.com https://*.gstatic.com http://*.google-analytics.com https://*.google-analytics.com https://*.slack-edge.com https://*.gravatar.com https://*.wp.com https://*.squarespace.com https://*.squarespace-cdn.com https://*.segment.io https://*.ingest.sentry.io https://*.intercomassets.com https://s-install.avcdn.net https://*.pushmetrics.io https://*.analytixlive.com https://dashboard.analytixapps.com http://localhost:3000; img-src data: 'self' https://*.stripe.com https://*.google.com https://*.googleapis.com https://unpkg.com https://*.segment.com http://*.segment.com https://*.amazonaws.com https://*.intercom.io https://*.intercomcdn.com https://*.gstatic.com http://*.google-analytics.com https://*.google-analytics.com https://*.slack-edge.com https://*.gravatar.com https://*.wp.com https://*.squarespace.com https://*.squarespace-cdn.com https://*.segment.io https://*.ingest.sentry.io https://*.intercomassets.com https://s-install.avcdn.net https://*.pushmetrics.io https://*.analytixlive.com https://dashboard.analytixapps.com http://localhost:3000; style-src 'self' 'unsafe-inline' https://*.stripe.com https://*.google.com https://*.googleapis.com https://unpkg.com https://*.segment.com http://*.segment.com https://*.amazonaws.com https://*.intercom.io https://*.intercomcdn.com https://*.gstatic.com http://*.google-analytics.com https://*.google-analytics.com https://*.slack-edge.com https://*.gravatar.com https://*.wp.com https://*.squarespace.com https://*.squarespace-cdn.com https://*.segment.io https://*.ingest.sentry.io https://*.intercomassets.com https://s-install.avcdn.net https://*.pushmetrics.io https://*.analytixlive.com https://dashboard.analytixapps.com http://localhost:3000; frame-src 'self' http://* https://* https://*.stripe.com https://*.google.com https://*.googleapis.com https://unpkg.com https://*.segment.com http://*.segment.com https://*.amazonaws.com https://*.intercom.io https://*.intercomcdn.com https://*.gstatic.com http://*.google-analytics.com https://*.google-analytics.com https://*.slack-edge.com https://*.gravatar.com https://*.wp.com https://*.squarespace.com https://*.squarespace-cdn.com https://*.segment.io https://*.ingest.sentry.io https://*.intercomassets.com https://s-install.avcdn.net https://*.pushmetrics.io https://*.analytixlive.com https://dashboard.analytixapps.com http://localhost:3000; font-src 'self' data: https://*.stripe.com https://*.google.com https://*.googleapis.com https://unpkg.com https://*.segment.com http://*.segment.com https://*.amazonaws.com https://*.intercom.io https://*.intercomcdn.com https://*.gstatic.com http://*.google-analytics.com https://*.google-analytics.com https://*.slack-edge.com https://*.gravatar.com https://*.wp.com https://*.squarespace.com https://*.squarespace-cdn.com https://*.segment.io https://*.ingest.sentry.io https://*.intercomassets.com https://s-install.avcdn.net https://*.pushmetrics.io https://*.analytixlive.com https://dashboard.analytixapps.com http://localhost:3000; frame-ancestors 'self' https://*.pushmetrics.io https://*.analytixlive.com https://*.google.com https://dashboard.analytixapps.com http://localhost:3000 https://*.stripe.com https://*.googleapis.com https://unpkg.com https://*.segment.com http://*.segment.com https://*.amazonaws.com https://*.intercom.io https://*.intercomcdn.com https://*.gstatic.com http://*.google-analytics.com https://*.google-analytics.com https://*.slack-edge.com https://*.gravatar.com https://*.wp.com https://*.squarespace.com https://*.squarespace-cdn.com https://*.segment.io https://*.ingest.sentry.io https://*.intercomassets.com https://s-install.avcdn.net;"}];
    
    
    
    headers["permissions-policy"] = [{key: "Permissions-Policy", value: "accelerometer=(self), ambient-light-sensor=(self), autoplay=(self), battery=(self), camera=(self), cross-origin-isolated=(self), display-capture=(self), document-domain=(self), encrypted-media=(self), execution-while-not-rendered=(self), execution-while-out-of-viewport=(self), fullscreen=(self), geolocation=(self), gyroscope=(self), keyboard-map=(self), magnetometer=(self), microphone=(self), midi=(self), navigation-override=(self), payment=(self), picture-in-picture=(self), publickey-credentials-get=(self), screen-wake-lock=(self), sync-xhr=(self), usb=(self), web-share=(self), xr-spatial-tracking=(self)"}];
    
    
    
    headers["referrer-policy"] = [{key: "Referrer-Policy", value: "same-origin"}];
    
    
    
    headers["server"] = [{key: "Server", value: "CloudFront"}];
    
    
    
    headers["strict-transport-security"] = [{key: "Strict-Transport-Security", value: "max-age=63072000; includeSubdomains; preload"}];
    
    
    
    headers["x-content-type-options"] = [{key: "X-Content-Type-Options", value: "nosniff"}];
    
    
    
    headers["x-frame-options"] = [{key: "X-Frame-Options", value: "SAMEORIGIN"}];
    
    
    
    headers["x-xss-protection"] = [{key: "X-XSS-Protection", value: "1; mode=block"}];
    
    
    //Return modified response
    callback(null, response);
};
